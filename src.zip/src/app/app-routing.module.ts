import { NgModule, ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { CadastroComponent } from './cadastro/cadastro.component';
import { ConstrucaoComponent } from './construcao/construcao.component';
import { LoginComponent } from './login/login.component';
import { ServicosComponent } from './servicos/servicos.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'cadastro', component: CadastroComponent },
  { path: 'agenda', component: ConstrucaoComponent },
  { path: 'login', component: LoginComponent },
  { path: 'servicos', component: ServicosComponent },
];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes);

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
