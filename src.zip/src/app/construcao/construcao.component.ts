import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-construcao',
  templateUrl: './construcao.component.html',
  styleUrls: ['./construcao.component.css']
})
export class ConstrucaoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
